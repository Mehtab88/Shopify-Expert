/* ==========================================
   Countdown Timer
========================================== */

let totalSeconds = 15 * 60;

const minuteElement = document.getElementById("minutes");
const secondElement = document.getElementById("seconds");

function updateCountdown() {

    if (!minuteElement || !secondElement) return;

    let minutes = Math.floor(totalSeconds / 60);
    let seconds = totalSeconds % 60;

    minuteElement.textContent =
        minutes < 10 ? "0" + minutes : minutes;

    secondElement.textContent =
        seconds < 10 ? "0" + seconds : seconds;

    if (totalSeconds > 0) {
        totalSeconds--;
    }

}

setInterval(updateCountdown, 1000);
updateCountdown();



/* ==========================================
   Smooth Scroll
========================================== */

document.querySelectorAll('a[href^="#"]').forEach(link => {

    link.addEventListener("click", function(e) {

        const target = document.querySelector(this.getAttribute("href"));

        if (target) {

            e.preventDefault();

            target.scrollIntoView({
                behavior: "smooth"
            });

        }

    });

});



/* ==========================================
   CTA Tracking
========================================== */

document.querySelectorAll(".cta-btn").forEach(button => {

    button.addEventListener("click", function() {

        console.log("CTA Button Clicked");

    });

});



/* ==========================================
   Sticky CTA
========================================== */

const stickyCTA = document.querySelector(".sticky-cta");

if (stickyCTA) {

    window.addEventListener("scroll", function() {

        if (window.scrollY > 400) {

            stickyCTA.style.display = "block";

        } else {

            stickyCTA.style.display = "none";

        }

    });

}



/* ==========================================
   Fade-in Animation
========================================== */

const observer = new IntersectionObserver((entries) => {

    entries.forEach(entry => {

        if (entry.isIntersecting) {

            entry.target.classList.add("show");

        }

    });

}, {
    threshold: 0.2
});

document.querySelectorAll("section").forEach(section => {

    section.classList.add("hidden");

    observer.observe(section);

});



/* ==========================================
   Image Zoom
========================================== */

document.querySelectorAll(".gallery-grid img").forEach(img => {

    img.addEventListener("click", function() {

        this.classList.toggle("zoom");

    });

});



/* ==========================================
   FAQ Toggle
========================================== */

document.querySelectorAll(".faq-item h3").forEach(title => {

    title.addEventListener("click", function() {

        const paragraph = this.nextElementSibling;

        if (!paragraph) return;

        if (paragraph.style.display === "block") {

            paragraph.style.display = "none";

        } else {

            paragraph.style.display = "block";

        }

    });

});



/* ==========================================
   Back To Top
========================================== */

const topButton = document.createElement("button");

topButton.innerHTML = "↑";

topButton.id = "topButton";

document.body.appendChild(topButton);

topButton.style.cssText = `
position:fixed;
right:20px;
bottom:90px;
width:50px;
height:50px;
border:none;
border-radius:50%;
background:#222;
color:#fff;
font-size:22px;
cursor:pointer;
display:none;
z-index:99999;
`;

window.addEventListener("scroll", () => {

    if (window.scrollY > 500) {

        topButton.style.display = "block";

    } else {

        topButton.style.display = "none";

    }

});

topButton.addEventListener("click", () => {

    window.scrollTo({
        top:0,
        behavior:"smooth"
    });

});



console.log("Landing Page Loaded Successfully");